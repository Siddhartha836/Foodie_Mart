// Order confirmation script
document.addEventListener('DOMContentLoaded', () => {
    // Load order details from localStorage
    const orderData = JSON.parse(localStorage.getItem('orderData')) || {};
    
    // Update order number with timestamp
    const orderNumber = document.getElementById('order-number');
    const timestamp = new Date().getTime();
    const randomPart = Math.floor(1000 + Math.random() * 9000);
    const formattedOrderNumber = `ORD-${timestamp}-${randomPart}`;
    orderNumber.textContent = `Order #${formattedOrderNumber}`;
    
    // Update delivery address
    const deliveryAddress = document.getElementById('delivery-address');
    if (orderData.address) {
        deliveryAddress.textContent = `Delivery Address: ${orderData.address}`;
    }
    
    // Update payment method
    const paymentMethod = document.querySelector('.order-details p:last-child');
    if (orderData.paymentMethod) {
        paymentMethod.textContent = `Payment Method: ${orderData.paymentMethod}`;
    }
    
    // Add animation to confirmation box
    const confirmationBox = document.querySelector('.confirmation-box');
    confirmationBox.style.opacity = '1';
    confirmationBox.style.transform = 'translateY(0)';
    
    // Show success toast
    showToast('Order placed successfully!');
});

// Toast message functionality
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Add animation
    toast.style.transform = 'translateY(0)';
    toast.style.opacity = '1';
    
    // Remove after 3 seconds
    setTimeout(() => {
        toast.style.transform = 'translateY(-100%)';
        toast.style.opacity = '0';
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

// Clear cart and address from localStorage
localStorage.removeItem('cart');
localStorage.removeItem('deliveryAddress');
