class Toast {
    constructor() {
        this.toastContainer = document.createElement('div');
        this.toastContainer.className = 'toast-container';
        document.body.appendChild(this.toastContainer);
    }

    show(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="toast-icon ${type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle'}"></i>
                <span>${message}</span>
            </div>
            <i class="fas fa-times close-toast"></i>
        `;

        this.toastContainer.appendChild(toast);
        
        // Add animation classes
        toast.style.transform = 'translateY(0)';
        toast.style.opacity = '1';

        // Remove toast after 3 seconds
        setTimeout(() => {
            toast.style.transform = 'translateY(-100%)';
            toast.style.opacity = '0';
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 3000);

        // Close on click
        toast.querySelector('.close-toast').addEventListener('click', () => {
            toast.style.transform = 'translateY(-100%)';
            toast.style.opacity = '0';
            setTimeout(() => {
                toast.remove();
            }, 300);
        });
    }
}

// Create a global toast instance
const toast = new Toast();
