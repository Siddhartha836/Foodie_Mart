// Swiggy-like functionality

// Mock data for restaurants
const restaurants = [
    {
        id: 1,
        name: "Dominos Pizza",
        rating: 4.5,
        cuisine: "Pizza, Italian",
        deliveryTime: "25-30 mins",
        image: "img/dominos.jpg",
        minOrder: 199,
        offers: "50% off on first order"
    },
    {
        id: 2,
        name: "Burger King",
        rating: 4.2,
        cuisine: "Burgers, Fast Food",
        deliveryTime: "20-25 mins",
        image: "img/burgerking.jpg",
        minOrder: 149,
        offers: "Get 1 free burger"
    },
    {
        id: 3,
        name: "KFC",
        rating: 4.3,
        cuisine: "Chicken, Fast Food",
        deliveryTime: "25-30 mins",
        image: "img/kfc.jpg",
        minOrder: 199,
        offers: "50% off on combo meals"
    },
    {
        id: 4,
        name: "Faasos",
        rating: 4.4,
        cuisine: "Wraps, Rolls",
        deliveryTime: "20-25 mins",
        image: "img/faasos.jpg",
        minOrder: 99,
        offers: "Free delivery"
    }
];

// Mock data for categories
const categories = [
    {
        id: 1,
        name: "Pizza",
        images: [
            "pizza/pizza1.jpg",
            "pizza/pizza2.jpg",
            "pizza/pizza3.jpg",
            "pizza/pizza4.jpg",
            "pizza/pizza5.jpg",
            "pizza/pizza6.jpg",
            "pizza/pizza7.jpg",
            "pizza/pizza8.jpg",
            "pizza/pizza9.jpg"
        ]
    },
    {
        id: 2,
        name: "Burger",
        images: [
            "burger/bur1.jpg",
            "burger/bur2.jpg",
            "burger/bur3.jpg",
            "burger/bur4.jpg",
            "burger/bur5.jpg",
            "burger/bur6.jpg",
            "burger/bur7.jpg",
            "burger/bur8.jpg",
            "burger/bur9.jpg",
            "burger/bur10.jpg"
        ]
    },
    {
        id: 3,
        name: "Biryani",
        images: [
            "biriyani/1.jpg",
            "biriyani/2.jpg",
            "biriyani/3.jpg",
            "biriyani/4.jpg",
            "biriyani/5.jpg",
            "biriyani/6.jpg",
            "biriyani/7.jpg",
            "biriyani/8.jpg",
            "biriyani/9.jpg",
            "biriyani/10.jpg"
        ]
    },
    {
        id: 4,
        name: "Chinese",
        images: [
            "chinese/11.jpg",
            "chinese/12.jpg",
            "chinese/13.jpg",
            "chinese/14.jpg",
            "chinese/15.jpg",
            "chinese/16.jpg",
            "chinese/17.jpg",
            "chinese/18.jpg",
            "chinese/19.jpg",
            "chinese/20.jpg"
        ]
    },
    {
        id: 5,
        name: "Desserts",
        images: [
            "deserts/21.jpg",
            "deserts/22.jpg",
            "deserts/23.jpg",
            "deserts/24.jpg",
            "deserts/25.jpg",
            "deserts/26.jpg",
            "deserts/27.jpg",
            "deserts/28.jpg",
            "deserts/29.jpg",
            "deserts/30.jpg",
            "deserts/31.jpg",
            "deserts/32.jpg",
            "deserts/33.jpg",
            "deserts/34.jpg",
            "deserts/35.jpg",
            "deserts/36.jpg",
            "deserts/37.jpg",
            "deserts/38.jpg",
            "deserts/39.jpg",
            "deserts/40.jpg"
        ]
    }
];

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    // Load categories
    const categoriesContainer = document.querySelector('.categories');
    categories.forEach(category => {
        const categoryCard = document.createElement('div');
        categoryCard.className = 'category-card';
        
        // Create image element
        const imgElement = document.createElement('img');
        imgElement.className = 'category-image';
        imgElement.src = category.images[0]; // Start with first image
        imgElement.alt = category.name;
        
        // Add image cycling functionality
        let currentImageIndex = 0;
        setInterval(() => {
            currentImageIndex = (currentImageIndex + 1) % category.images.length;
            imgElement.src = category.images[currentImageIndex];
        }, 3000); // Change image every 3 seconds
        
        // Create heading
        const heading = document.createElement('h3');
        heading.textContent = category.name;
        
        // Append elements to card
        categoryCard.appendChild(imgElement);
        categoryCard.appendChild(heading);
        
        categoriesContainer.appendChild(categoryCard);
    });

    // Load restaurants
    const restaurantGrid = document.querySelector('.restaurant-grid');
    restaurants.forEach(restaurant => {
        const restaurantCard = document.createElement('div');
        restaurantCard.className = 'restaurant-card';
        restaurantCard.innerHTML = `
            <img src="${restaurant.image}" alt="${restaurant.name}">
            <div class="restaurant-info">
                <h3>${restaurant.name}</h3>
                <div class="rating">${restaurant.rating} ⭐</div>
                <div class="cuisine">${restaurant.cuisine}</div>
                <div class="delivery-time">${restaurant.deliveryTime}</div>
                <div class="offers">${restaurant.offers}</div>
                <div class="min-order">₹${restaurant.minOrder} min</div>
                <button onclick="viewRestaurant(${restaurant.id})" class="order-btn">Order Online</button>
            </div>
        `;
        restaurantGrid.appendChild(restaurantCard);
    });

    // Search functionality
    const searchInput = document.querySelector('.search-input');
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const filteredRestaurants = restaurants.filter(restaurant => 
            restaurant.name.toLowerCase().includes(searchTerm)
        );
        
        // Update restaurant grid with filtered results
        restaurantGrid.innerHTML = '';
        filteredRestaurants.forEach(restaurant => {
            const restaurantCard = document.createElement('div');
            restaurantCard.className = 'restaurant-card';
            restaurantCard.innerHTML = `
                <img src="${restaurant.image}" alt="${restaurant.name}">
                <div class="restaurant-info">
                    <h3>${restaurant.name}</h3>
                    <div class="rating">${restaurant.rating} ⭐</div>
                    <div class="cuisine">${restaurant.cuisine}</div>
                    <div class="delivery-time">${restaurant.deliveryTime}</div>
                    <div class="offers">${restaurant.offers}</div>
                    <div class="min-order">₹${restaurant.minOrder} min</div>
                    <button onclick="viewRestaurant(${restaurant.id})" class="order-btn">Order Online</button>
                </div>
            `;
            restaurantGrid.appendChild(restaurantCard);
        });
    });
});

// View restaurant details
function viewRestaurant(restaurantId) {
    const restaurant = restaurants.find(r => r.id === restaurantId);
    if (restaurant) {
        localStorage.setItem('selectedRestaurant', JSON.stringify(restaurant));
        window.location.href = 'menu.html';
    }
}

// Handle user session
function handleUserSession() {
    const user = localStorage.getItem('user');
    const loginLink = document.querySelector('.nav-links a[href="login.html"]');
    
    if (user) {
        loginLink.textContent = 'Logout';
        loginLink.href = '#';
        loginLink.onclick = () => {
            localStorage.removeItem('user');
            window.location.href = 'login.html';
            return false;
        };
    }
}

// Initialize session on page load
document.addEventListener('DOMContentLoaded', handleUserSession);
