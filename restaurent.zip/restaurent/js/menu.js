// Menu items data
const menuItems = [
    // Biryani Combos (5 items)
    {
        id: 1,
        name: "Biryani Special",
        price: 650,
        category: "biryani",
        image: "combo/c1 (1).jpg",
        description: "2 Biryani + 2 Raita + 2 Drinks + 1 Dessert"
    },
    {
        id: 2,
        name: "Biryani Platter",
        price: 750,
        category: "biryani",
        image: "combo/c1 (2).jpg",
        description: "2 Biryani + 2 Raita + 2 Drinks + 2 Desserts"
    },
    {
        id: 3,
        name: "Biryani Family Pack",
        price: 850,
        category: "biryani",
        image: "combo/c1 (3).jpg",
        description: "3 Biryani + 3 Raita + 3 Drinks + 2 Desserts"
    },
    {
        id: 4,
        name: "Biryani Feast",
        price: 950,
        category: "biryani",
        image: "combo/c1 (4).jpg",
        description: "4 Biryani + 4 Raita + 4 Drinks + 3 Desserts"
    },
    {
        id: 5,
        name: "Biryani Special",
        price: 650,
        category: "biryani",
        image: "combo/c1 (5).jpg",
        description: "2 Biryani + 2 Raita + 2 Drinks + 1 Dessert"
    },

    // Burger Combos (5 items)
    {
        id: 6,
        name: "Burger Bonanza",
        price: 400,
        category: "burger",
        image: "combo/c2 (1).jpg",
        description: "4 Burgers + 2 Drinks + 1 Dessert"
    },
    {
        id: 7,
        name: "Burger Party",
        price: 500,
        category: "burger",
        image: "combo/c2 (2).jpg",
        description: "6 Burgers + 3 Drinks + 2 Desserts"
    },
    {
        id: 8,
        name: "Burger Family",
        price: 600,
        category: "burger",
        image: "combo/c2 (3).jpg",
        description: "8 Burgers + 4 Drinks + 3 Desserts"
    },
    {
        id: 9,
        name: "Burger Feast",
        price: 700,
        category: "burger",
        image: "combo/c2 (4).jpg",
        description: "10 Burgers + 5 Drinks + 4 Desserts"
    },
    {
        id: 10,
        name: "Burger Special",
        price: 450,
        category: "burger",
        image: "combo/c2 (5).jpg",
        description: "3 Burgers + 2 Drinks + 1 Dessert"
    },

    // Chinese Combos (5 items)
    {
        id: 11,
        name: "Chinese Delight",
        price: 500,
        category: "chinese",
        image: "combo/c3 (1).jpg",
        description: "2 Manchurians + 2 Noodles + 2 Drinks + 1 Dessert"
    },
    {
        id: 12,
        name: "Chinese Platter",
        price: 600,
        category: "chinese",
        image: "combo/c3 (2).jpg",
        description: "3 Manchurians + 3 Noodles + 3 Drinks + 2 Desserts"
    },
    {
        id: 13,
        name: "Chinese Family",
        price: 700,
        category: "chinese",
        image: "combo/c3 (3).jpg",
        description: "4 Manchurians + 4 Noodles + 4 Drinks + 3 Desserts"
    },
    {
        id: 14,
        name: "Chinese Feast",
        price: 800,
        category: "chinese",
        image: "combo/c3 (4).jpg",
        description: "5 Manchurians + 5 Noodles + 5 Drinks + 4 Desserts"
    },
    {
        id: 15,
        name: "Chinese Special",
        price: 550,
        category: "chinese",
        image: "combo/c3 (5).jpg",
        description: "3 Manchurians + 2 Noodles + 2 Drinks + 1 Dessert"
    },

    // Pizza Combos (5 items)
    {
        id: 16,
        name: "Pizza Party",
        price: 700,
        category: "pizza",
        image: "combo/c4 (1).jpg",
        description: "3 Large pizzas + 3 Drinks + 1 Dessert"
    },
    {
        id: 17,
        name: "Pizza Platter",
        price: 800,
        category: "pizza",
        image: "combo/c4 (2).jpg",
        description: "4 Large pizzas + 4 Drinks + 2 Desserts"
    },
    {
        id: 18,
        name: "Pizza Family",
        price: 900,
        category: "pizza",
        image: "combo/c4 (3).jpg",
        description: "5 Large pizzas + 5 Drinks + 3 Desserts"
    },
    {
        id: 19,
        name: "Pizza Feast",
        price: 1000,
        category: "pizza",
        image: "combo/c4 (4).jpg",
        description: "6 Large pizzas + 6 Drinks + 4 Desserts"
    },
    {
        id: 20,
        name: "Pizza Special",
        price: 750,
        category: "pizza",
        image: "combo/c4 (5).jpg",
        description: "4 Large pizzas + 4 Drinks + 2 Desserts"
    },

    // Pizza Items (9 items)
    // Biryani Combos (4 items)
    {
        id: 1,
        name: "Biryani Special",
        price: 650,
        category: "biryani",
        image: "combo/c1 (1).jpg",
        description: "2 Biryani + 2 Raita + 2 Drinks + 1 Dessert"
    },
    {
        id: 2,
        name: "Biryani Platter",
        price: 750,
        category: "biryani",
        image: "combo/c2 (1).jpg",
        description: "2 Biryani + 2 Raita + 2 Drinks + 2 Desserts"
    },
    {
        id: 3,
        name: "Biryani Family Pack",
        price: 850,
        category: "biryani",
        image: "combo/c3 (1).jpg",
        description: "3 Biryani + 3 Raita + 3 Drinks + 2 Desserts"
    },
    {
        id: 4,
        name: "Biryani Feast",
        price: 950,
        category: "biryani",
        image: "combo/c4 (1).jpg",
        description: "4 Biryani + 4 Raita + 4 Drinks + 3 Desserts"
    },

    // Burger Combos (4 items)
    {
        id: 5,
        name: "Burger Bonanza",
        price: 400,
        category: "burger",
        image: "combo/c1 (2).jpg",
        description: "4 Burgers + 2 Drinks + 1 Dessert"
    },
    {
        id: 6,
        name: "Burger Party",
        price: 500,
        category: "burger",
        image: "combo/c2 (2).jpg",
        description: "6 Burgers + 3 Drinks + 2 Desserts"
    },
    {
        id: 7,
        name: "Burger Family",
        price: 600,
        category: "burger",
        image: "combo/c3 (2).jpg",
        description: "8 Burgers + 4 Drinks + 3 Desserts"
    },
    {
        id: 8,
        name: "Burger Feast",
        price: 700,
        category: "burger",
        image: "combo/c4 (2).jpg",
        description: "10 Burgers + 5 Drinks + 4 Desserts"
    },

    // Chinese Combos (4 items)
    {
        id: 9,
        name: "Chinese Delight",
        price: 500,
        category: "chinese",
        image: "combo/c1 (3).jpg",
        description: "2 Manchurians + 2 Noodles + 2 Drinks + 1 Dessert"
    },
    {
        id: 10,
        name: "Chinese Platter",
        price: 600,
        category: "chinese",
        image: "combo/c2 (3).jpg",
        description: "3 Manchurians + 3 Noodles + 3 Drinks + 2 Desserts"
    },
    {
        id: 11,
        name: "Chinese Family",
        price: 700,
        category: "chinese",
        image: "combo/c3 (3).jpg",
        description: "4 Manchurians + 4 Noodles + 4 Drinks + 3 Desserts"
    },
    {
        id: 12,
        name: "Chinese Feast",
        price: 800,
        category: "chinese",
        image: "combo/c4 (3).jpg",
        description: "5 Manchurians + 5 Noodles + 5 Drinks + 4 Desserts"
    },

    // Pizza Combos (4 items)
    {
        id: 13,
        name: "Pizza Party",
        price: 700,
        category: "pizza",
        image: "combo/c1 (4).jpg",
        description: "3 Large pizzas + 3 Drinks + 1 Dessert"
    },
    {
        id: 14,
        name: "Pizza Platter",
        price: 800,
        category: "pizza",
        image: "combo/c2 (4).jpg",
        description: "4 Large pizzas + 4 Drinks + 2 Desserts"
    },
    {
        id: 15,
        name: "Pizza Family",
        price: 900,
        category: "pizza",
        image: "combo/c3 (4).jpg",
        description: "5 Large pizzas + 5 Drinks + 3 Desserts"
    },
    {
        id: 16,
        name: "Pizza Feast",
        price: 1000,
        category: "pizza",
        image: "combo/c4 (4).jpg",
        description: "6 Large pizzas + 6 Drinks + 4 Desserts"
    },

    // Pizza Items (9 items)
    // Pizza Items (9 items)
    {
        id: 1,
        name: "Classic Margherita",
        price: 250,
        category: "pizza",
        image: "pizza/pizza1.jpg",
        description: "Classic pizza with fresh tomatoes and mozzarella cheese"
    },
    {
        id: 2,
        name: "Pepperoni Pizza",
        price: 280,
        category: "pizza",
        image: "pizza/pizza2.jpg",
        description: "Spicy pepperoni with extra cheese"
    },
    {
        id: 3,
        name: "Veggie Supreme",
        price: 300,
        category: "pizza",
        image: "pizza/pizza3.jpg",
        description: "Loaded with fresh vegetables and cheese"
    },
    {
        id: 4,
        name: "Cheese Burst",
        price: 350,
        category: "pizza",
        image: "pizza/pizza4.jpg",
        description: "Double cheese with melty cheese center"
    },
    {
        id: 5,
        name: "Farmhouse Pizza",
        price: 290,
        category: "pizza",
        image: "pizza/pizza5.jpg",
        description: "Fresh vegetables with cheese"
    },
    {
        id: 6,
        name: "Paneer Tikka",
        price: 320,
        category: "pizza",
        image: "pizza/pizza6.jpg",
        description: "Grilled paneer with spices"
    },
    {
        id: 7,
        name: "Mushroom Pizza",
        price: 270,
        category: "pizza",
        image: "pizza/pizza7.jpg",
        description: "Fresh mushrooms with cheese"
    },
    {
        id: 8,
        name: "Chicken Supreme",
        price: 330,
        category: "pizza",
        image: "pizza/pizza8.jpg",
        description: "Grilled chicken with vegetables"
    },
    {
        id: 9,
        name: "Margherita Special",
        price: 260,
        category: "pizza",
        image: "pizza/pizza9.jpg",
        description: "Classic Italian style"
    },

    // Burger Items (10 items)
    {
        id: 10,
        name: "Classic Burger",
        price: 150,
        category: "burger",
        image: "burger/bur1.jpg",
        description: "Juicy beef patty with fresh vegetables"
    },
    {
        id: 11,
        name: "Cheese Burger",
        price: 180,
        category: "burger",
        image: "burger/bur2.jpg",
        description: "Beef patty with extra cheese"
    },
    {
        id: 12,
        name: "Chicken Burger",
        price: 170,
        category: "burger",
        image: "burger/bur3.jpg",
        description: "Grilled chicken with fresh salad"
    },
    {
        id: 13,
        name: "Veggie Burger",
        price: 140,
        category: "burger",
        image: "burger/bur4.jpg",
        description: "Fresh vegetables with special sauce"
    },
    {
        id: 14,
        name: "Double Cheese",
        price: 200,
        category: "burger",
        image: "burger/bur5.jpg",
        description: "Double cheese with beef patty"
    },
    {
        id: 15,
        name: "Spicy Burger",
        price: 190,
        category: "burger",
        image: "burger/bur6.jpg",
        description: "Extra spicy with jalapenos"
    },
    {
        id: 16,
        name: "Veggie Supreme",
        price: 160,
        category: "burger",
        image: "burger/bur7.jpg",
        description: "Loaded with vegetables"
    },
    {
        id: 17,
        name: "Chicken Cheese",
        price: 210,
        category: "burger",
        image: "burger/bur8.jpg",
        description: "Grilled chicken with cheese"
    },
    {
        id: 18,
        name: "Mushroom Burger",
        price: 220,
        category: "burger",
        image: "burger/bur9.jpg",
        description: "Fresh mushrooms with beef"
    },
    {
        id: 19,
        name: "Patty Special",
        price: 230,
        category: "burger",
        image: "burger/bur10.jpg",
        description: "Special beef patty"
    },

    // Biryani Items (10 items)
    {
        id: 20,
        name: "Chicken Biryani",
        price: 280,
        category: "biryani",
        image: "biriyani/1.jpg",
        description: "Tandoori chicken with aromatic rice"
    },
    {
        id: 21,
        name: "Mutton Biryani",
        price: 350,
        category: "biryani",
        image: "biriyani/2.jpg",
        description: "Tender mutton with special spices"
    },
    {
        id: 22,
        name: "Hyderabadi Biryani",
        price: 320,
        category: "biryani",
        image: "biriyani/3.jpg",
        description: "Authentic Hyderabadi style"
    },
    {
        id: 23,
        name: "Veg Biryani",
        price: 250,
        category: "biryani",
        image: "biriyani/4.jpg",
        description: "Fresh vegetables with special spices"
    },
    {
        id: 24,
        name: "Egg Biryani",
        price: 270,
        category: "biryani",
        image: "biriyani/5.jpg",
        description: "Eggs with aromatic rice"
    },
    {
        id: 25,
        name: "Paneer Biryani",
        price: 290,
        category: "biryani",
        image: "biriyani/6.jpg",
        description: "Grilled paneer with special spices"
    },
    {
        id: 26,
        name: "Chicken Special",
        price: 300,
        category: "biryani",
        image: "biriyani/7.jpg",
        description: "Special chicken recipe"
    },
    {
        id: 27,
        name: "Mutton Special",
        price: 370,
        category: "biryani",
        image: "biriyani/8.jpg",
        description: "Premium mutton"
    },
    {
        id: 28,
        name: "Veg Special",
        price: 260,
        category: "biryani",
        image: "biriyani/9.jpg",
        description: "Special vegetable mix"
    },
    {
        id: 29,
        name: "Egg Special",
        price: 280,
        category: "biryani",
        image: "biriyani/10.jpg",
        description: "Special egg recipe"
    },

    // Chinese Items (10 items)
    {
        id: 30,
        name: "Manchurian",
        price: 180,
        category: "chinese",
        image: "chinese/11.jpg",
        description: "Classic Manchurian with special sauce"
    },
    {
        id: 31,
        name: "Chow Mein",
        price: 150,
        category: "chinese",
        image: "chinese/12.jpg",
        description: "Fresh noodles with vegetables"
    },
    {
        id: 32,
        name: "Spring Rolls",
        price: 120,
        category: "chinese",
        image: "chinese/13.jpg",
        description: "Fresh spring rolls with special sauce"
    },
    {
        id: 33,
        name: "Fried Rice",
        price: 160,
        category: "chinese",
        image: "chinese/14.jpg",
        description: "Special fried rice with vegetables"
    },
    {
        id: 34,
        name: "Hakka Noodles",
        price: 170,
        category: "chinese",
        image: "chinese/15.jpg",
        description: "Special Hakka noodles"
    },
    {
        id: 35,
        name: "Chilli Paneer",
        price: 200,
        category: "chinese",
        image: "chinese/16.jpg",
        description: "Grilled paneer with special sauce"
    },
    {
        id: 36,
        name: "Schezwan Noodles",
        price: 190,
        category: "chinese",
        image: "chinese/17.jpg",
        description: "Spicy noodles with vegetables"
    },
    {
        id: 37,
        name: "Chicken Manchurian",
        price: 210,
        category: "chinese",
        image: "chinese/18.jpg",
        description: "Chicken with special sauce"
    },
    {
        id: 38,
        name: "Egg Fried Rice",
        price: 180,
        category: "chinese",
        image: "chinese/19.jpg",
        description: "Eggs with fried rice"
    },
    {
        id: 39,
        name: "Veg Special",
        price: 170,
        category: "chinese",
        image: "chinese/20.jpg",
        description: "Special vegetable mix"
    },

    // Dessert Items (20 items)
    {
        id: 40,
        name: "Ice Cream",
        price: 100,
        category: "dessert",
        image: "deserts/21.jpg",
        description: "Fresh ice cream with toppings"
    },
    {
        id: 41,
        name: "Brownie",
        price: 120,
        category: "dessert",
        image: "deserts/22.jpg",
        description: "Rich chocolate brownie"
    },
    {
        id: 42,
        name: "Cake",
        price: 250,
        category: "dessert",
        image: "deserts/23.jpg",
        description: "Special cake with toppings"
    },
    {
        id: 43,
        name: "Pudding",
        price: 150,
        category: "dessert",
        image: "deserts/24.jpg",
        description: "Special pudding with cream"
    },
    {
        id: 44,
        name: "Milkshake",
        price: 130,
        category: "dessert",
        image: "deserts/25.jpg",
        description: "Fresh milkshake with ice cream"
    },
    {
        id: 45,
        name: "Falooda",
        price: 180,
        category: "dessert",
        image: "deserts/26.jpg",
        description: "Special falooda with ice cream"
    },
    {
        id: 46,
        name: "Gulab Jamun",
        price: 140,
        category: "dessert",
        image: "deserts/27.jpg",
        description: "Sweet gulab jamun"
    },
    {
        id: 47,
        name: "Kulfi",
        price: 160,
        category: "dessert",
        image: "deserts/28.jpg",
        description: "Traditional kulfi"
    },
    {
        id: 48,
        name: "Rasmalai",
        price: 200,
        category: "dessert",
        image: "deserts/29.jpg",
        description: "Sweet rasmalai"
    },
    {
        id: 49,
        name: "Barfi",
        price: 120,
        category: "dessert",
        image: "deserts/30.jpg",
        description: "Traditional barfi"
    },
    {
        id: 50,
        name: "Jalebi",
        price: 100,
        category: "dessert",
        image: "deserts/31.jpg",
        description: "Sweet jalebi"
    },
    {
        id: 51,
        name: "Rasgulla",
        price: 150,
        category: "dessert",
        image: "deserts/32.jpg",
        description: "Sweet rasgulla"
    },
    {
        id: 52,
        name: "Ladoo",
        price: 130,
        category: "dessert",
        image: "deserts/33.jpg",
        description: "Sweet ladoo"
    },
    {
        id: 53,
        name: "Kheer",
        price: 180,
        category: "dessert",
        image: "deserts/34.jpg",
        description: "Sweet kheer"
    },
    {
        id: 54,
        name: "Payasam",
        price: 170,
        category: "dessert",
        image: "deserts/35.jpg",
        description: "Sweet payasam"
    },
    {
        id: 55,
        name: "Halwa",
        price: 190,
        category: "dessert",
        image: "deserts/36.jpg",
        description: "Sweet halwa"
    },
    {
        id: 56,
        name: "Shrikhand",
        price: 210,
        category: "dessert",
        image: "deserts/37.jpg",
        description: "Sweet shrikhand"
    },
    {
        id: 57,
        name: "Peda",
        price: 140,
        category: "dessert",
        image: "deserts/38.jpg",
        description: "Sweet peda"
    },
    {
        id: 58,
        name: "Mysore Pak",
        price: 160,
        category: "dessert",
        image: "deserts/39.jpg",
        description: "Sweet mysore pak"
    },
    {
        id: 59,
        name: "Gajar Halwa",
        price: 180,
        category: "dessert",
        image: "deserts/40.jpg",
        description: "Sweet carrot halwa"
    }
];

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    // Load menu items
    const menuGrid = document.querySelector('.menu-grid');
    const searchInput = document.querySelector('.search-input');
    const categoryButtons = document.querySelectorAll('.category-btn');

    // Display all items initially
    displayMenuItems('all');

    // Category filter functionality
    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');
            // Filter items
            const category = button.getAttribute('data-category');
            displayMenuItems(category);
        });
    });

    // Search functionality
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const filteredItems = menuItems.filter(item => 
            item.name.toLowerCase().includes(searchTerm) ||
            item.description.toLowerCase().includes(searchTerm)
        );
        displayMenuItems('all', filteredItems);
    });
});

// Display menu items based on category
function displayMenuItems(category, items = menuItems) {
    const menuGrid = document.querySelector('.menu-grid');
    menuGrid.innerHTML = '';

    const filteredItems = category === 'all' ? items : 
        items.filter(item => item.category === category);

    filteredItems.forEach(item => {
        const menuItem = document.createElement('div');
        menuItem.className = 'menu-item';
        menuItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <div class="menu-item-info">
                <h3>${item.name}</h3>
                <p class="price">₹${item.price}</p>
                <p class="description">${item.description}</p>
                <div class="item-actions">
                    <button onclick="addToCart(${item.id})" class="add-to-cart">Add to Cart</button>
                    <span class="item-count">0</span>
                </div>
            </div>
        `;
        menuGrid.appendChild(menuItem);
    });
}

// Cart functionality
let cart = JSON.parse(localStorage.getItem('cart')) || {};

function addToCart(itemId) {
    const item = menuItems.find(item => item.id === itemId);
    if (item) {
        if (!cart[itemId]) {
            cart[itemId] = {
                ...item,
                quantity: 1
            };
        } else {
            cart[itemId].quantity += 1;
        }
        
        // Update local storage
        cart.push(item);
        localStorage.setItem('cart', JSON.stringify(cart));
        alert(`${item.name} has been added to your cart!`);
    }
}
