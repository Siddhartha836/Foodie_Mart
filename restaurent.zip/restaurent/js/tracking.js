// Order tracking script
document.addEventListener('DOMContentLoaded', () => {
    // Get order details from localStorage
    const orderData = JSON.parse(localStorage.getItem('orderData')) || {};
    
    // Update order number
    const orderNumber = document.querySelector('.contact-info p:first-child');
    if (orderData.orderNumber) {
        orderNumber.textContent = `Order Number: ${orderData.orderNumber}`;
    }
    
    // Update delivery address
    const address = document.querySelector('.contact-info p:nth-child(2)');
    if (orderData.address) {
        address.textContent = `Delivery Address: ${orderData.address}`;
    }
    
    // Update phone number
    const phone = document.querySelector('.contact-info p:nth-child(3)');
    if (orderData.phone) {
        phone.textContent = `Phone: ${orderData.phone}`;
    }
    
    // Initialize tracking
    initializeTracking();
    
    // Update tracking status periodically
    setInterval(updateTrackingStatus, 30000); // Update every 30 seconds
});

// Initialize tracking
function initializeTracking() {
    // Simulate initial tracking data
    const trackingSteps = document.querySelectorAll('.step');
    trackingSteps[0].classList.add('completed');
    trackingSteps[1].classList.add('current');
    
    // Add animation to tracking steps
    trackingSteps.forEach((step, index) => {
        setTimeout(() => {
            step.style.transform = 'scale(1.1)';
            step.style.opacity = '1';
        }, 300 * index);
    });
}

// Update tracking status
function updateTrackingStatus() {
    // Get current status
    const currentStep = document.querySelector('.step.current');
    const nextStep = currentStep.nextElementSibling;
    
    if (nextStep) {
        // Update status
        currentStep.classList.remove('current');
        currentStep.classList.add('completed');
        nextStep.classList.add('current');
        
        // Update status message
        const status = document.querySelector('.order-status h2');
        const eta = document.querySelector('.eta');
        
        switch (nextStep.querySelector('.step-number').textContent) {
            case '3':
                status.textContent = 'Your order is on the way';
                eta.textContent = 'Estimated Arrival: 15-20 minutes';
                break;
            case '4':
                status.textContent = 'Order Delivered Successfully!';
                eta.textContent = 'Thank you for choosing FoodieMart!';
                break;
        }
        
        // Add animation
        nextStep.style.transform = 'scale(1.1)';
        setTimeout(() => {
            nextStep.style.transform = 'scale(1)';
        }, 300);
    }
}

// Add loading animation to map
function addMapAnimation() {
    const map = document.querySelector('.tracking-map');
    const animation = document.createElement('div');
    animation.className = 'map-animation';
    animation.innerHTML = `
        <div class="map-dot"></div>
        <div class="map-path"></div>
    `;
    map.appendChild(animation);
    
    // Animate dot movement
    const dot = document.querySelector('.map-dot');
    const path = document.querySelector('.map-path');
    
    // Add animation styles
    dot.style.animation = 'dotMove 3s infinite linear';
    path.style.animation = 'pathDraw 3s infinite linear';
}

// Add animations
function addAnimations() {
    // Add fade-in animation to tracking box
    const trackingBox = document.querySelector('.tracking-box');
    trackingBox.style.opacity = '1';
    trackingBox.style.transform = 'translateY(0)';
    
    // Add map animation
    addMapAnimation();
}

// Add animations when page loads
addAnimations();
