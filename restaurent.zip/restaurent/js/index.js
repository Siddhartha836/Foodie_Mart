// Initialize AOS (Animate On Scroll)
AOS.init({
    duration: 1000,
    once: true
});

// Loading Animation
window.addEventListener('load', function() {
    const loader = document.querySelector('.loader-container');
    loader.style.opacity = '0';
    setTimeout(() => {
        loader.style.display = 'none';
    }, 1000);
});

// Category Image Rotation
function rotateImages() {
    const sliders = document.querySelectorAll('.category-image');
    
    sliders.forEach(slider => {
        const images = slider.querySelectorAll('img');
        const current = slider.querySelector('.active');
        
        if (current) {
            current.classList.remove('active');
        }
        
        const nextIndex = (Array.from(images).indexOf(current) + 1) % images.length;
        images[nextIndex].classList.add('active');
    });
}

// Start image rotation every 2.5 seconds with initial delay
setTimeout(() => {
    setInterval(rotateImages, 2500);
}, 1000);

// Navbar Scroll Effect
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Smooth Scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Search Functionality
document.querySelector('.search-input').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const restaurants = document.querySelectorAll('.restaurant-card');
    
    restaurants.forEach(restaurant => {
        const name = restaurant.querySelector('h3').textContent.toLowerCase();
        if (name.includes(searchTerm)) {
            restaurant.style.display = 'block';
        } else {
            restaurant.style.display = 'none';
        }
    });
});

// Category Filtering
document.querySelectorAll('.category-card').forEach(category => {
    category.addEventListener('click', function() {
        const categoryName = this.querySelector('h3').textContent.toLowerCase();
        const restaurants = document.querySelectorAll('.restaurant-card');
        
        restaurants.forEach(restaurant => {
            const cuisine = restaurant.querySelector('p').textContent.toLowerCase();
            if (cuisine.includes(categoryName)) {
                restaurant.style.display = 'block';
            } else {
                restaurant.style.display = 'none';
            }
        });
    });
});

// Offer Cards
document.querySelectorAll('.offer-btn').forEach(button => {
    button.addEventListener('click', function() {
        const offerCard = this.closest('.offer-card');
        const offerText = offerCard.querySelector('h3').textContent;
        alert(`You've selected: ${offerText}`);
    });
});

// Restaurant Cards
document.querySelectorAll('.restaurant-card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-5px)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
    });
});

// Social Media Links
document.querySelectorAll('.social-icon').forEach(icon => {
    icon.addEventListener('click', function(e) {
        e.preventDefault();
        const platform = this.querySelector('i').classList[1];
        alert(`Opening ${platform}...`);
    });
});
