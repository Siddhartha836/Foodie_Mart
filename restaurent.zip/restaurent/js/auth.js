// Authentication script
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Simple mock authentication
    if (email && password) {
        localStorage.setItem('user', email);
        window.location.href = 'menu.html';
    } else {
        alert('Please enter valid credentials');
    }
});
