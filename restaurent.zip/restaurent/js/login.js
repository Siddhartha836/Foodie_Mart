// Login functionality
function continueWithPhone() {
    const phone = document.getElementById('phone').value;
    const loginBox = document.querySelector('.login-box');
    
    // Validate phone number
    if (!phone || phone.length !== 10) {
        toast.show('Please enter a valid 10-digit phone number', 'error');
        return;
    }

    // Add loading animation
    const continueBtn = document.querySelector('.continue-btn');
    continueBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
    continueBtn.disabled = true;

    // Simulate API call
    setTimeout(() => {
        // Store phone number in localStorage
        localStorage.setItem('userPhone', phone);
        
        // Show success toast
        toast.show('Phone number verified successfully!');
        
        // Add slide animation to login box
        loginBox.style.transform = 'translateX(-100%)';
        loginBox.style.opacity = '0';
        
        // Redirect after animation
        setTimeout(() => {
            window.location.href = 'otp.html';
        }, 500);
    }, 1000);
}

// Social login handlers
function continueWithGoogle() {
    const socialBtn = document.querySelector('.google-btn');
    socialBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting...';
    socialBtn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        toast.show('Google login coming soon!', 'error');
        socialBtn.innerHTML = '<i class="fab fa-google"></i> Continue with Google';
        socialBtn.disabled = false;
    }, 1000);
}

function continueWithFacebook() {
    const socialBtn = document.querySelector('.facebook-btn');
    socialBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting...';
    socialBtn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        toast.show('Facebook login coming soon!', 'error');
        socialBtn.innerHTML = '<i class="fab fa-facebook-f"></i> Continue with Facebook';
        socialBtn.disabled = false;
    }, 1000);
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Add click handlers for social login buttons
    const googleBtn = document.querySelector('.google-btn');
    const facebookBtn = document.querySelector('.facebook-btn');
    
    googleBtn.addEventListener('click', continueWithGoogle);
    facebookBtn.addEventListener('click', continueWithFacebook);
    
    // Add hover animations
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', () => {
            button.style.transform = 'translateY(-2px)';
        });
        button.addEventListener('mouseleave', () => {
            button.style.transform = 'translateY(0)';
        });
    });
});
