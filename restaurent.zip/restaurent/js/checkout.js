// Initialize checkout system
document.addEventListener('DOMContentLoaded', () => {
    // Load cart items
    const summaryItems = document.querySelector('.summary-items');
    const placeOrderBtn = document.getElementById('placeOrder');
    
    // Get cart from localStorage
    let cart = JSON.parse(localStorage.getItem('cart')) || {};
    
    // Display order items
    displayOrderItems();
    
    // Update order summary
    updateOrderSummary();
    
    // Place order button click handler
    placeOrderBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        
        // Validate form
        const form = document.getElementById('deliveryForm');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        
        // Get form data
        const formData = {
            name: form.name.value,
            phone: form.phone.value,
            address: form.address.value,
            pincode: form.pincode.value,
            paymentMethod: form.querySelector('input[name="payment"]:checked').value,
            items: Object.values(cart)
        };
        
        // Show loading state
        placeOrderBtn.disabled = true;
        placeOrderBtn.textContent = 'Placing Order...';
        
        try {
            // Simulate order placement
            const orderData = await simulateOrderPlacement(formData);
            
            // Save order data to localStorage
            localStorage.setItem('orderData', JSON.stringify({
                ...orderData,
                ...formData
            }));
            
            // Clear cart
            localStorage.removeItem('cart');
            
            // Redirect to confirmation page
            window.location.href = 'confirmation.html';
        } catch (error) {
            alert('Failed to place order. Please try again.');
            placeOrderBtn.disabled = false;
            placeOrderBtn.textContent = 'Place Order';
        }
    });
});

// Display order items
function displayOrderItems() {
    const summaryItems = document.querySelector('.summary-items');
    const cart = JSON.parse(localStorage.getItem('cart')) || {};
    
    summaryItems.innerHTML = '';
    
    Object.values(cart).forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.className = 'order-item';
        itemElement.innerHTML = `
            <div class="order-item-info">
                <h3>${item.name}</h3>
                <p class="quantity">Quantity: ${item.quantity}</p>
                <p class="price">₹${item.price * item.quantity}</p>
            </div>
        `;
        summaryItems.appendChild(itemElement);
    });
}

// Update order summary
function updateOrderSummary() {
    const cart = JSON.parse(localStorage.getItem('cart')) || {};
    
    let itemCount = 0;
    let subtotal = 0;
    
    Object.values(cart).forEach(item => {
        itemCount += item.quantity;
        subtotal += item.price * item.quantity;
    });
    
    document.getElementById('checkout-item-count').textContent = itemCount;
    document.getElementById('checkout-subtotal').textContent = `₹${subtotal}`;
    document.getElementById('checkout-total').textContent = `₹${subtotal}`;
}

// Simulate order placement (In a real app, this would make an API call)
async function simulateOrderPlacement(formData) {
    return new Promise((resolve, reject) => {
        // Generate unique order number
        const timestamp = new Date().getTime();
        const randomPart = Math.floor(1000 + Math.random() * 9000);
        const orderNumber = `ORD-${timestamp}-${randomPart}`;
        
        // Simulate API call
        setTimeout(() => {
            // Here you would typically make an API call to place the order
            // For now, we'll just simulate success
            resolve({
                orderNumber: orderNumber,
                status: 'placed',
                timestamp: timestamp,
                estimatedDelivery: new Date().getTime() + (45 * 60 * 1000) // 45 minutes from now
            });
        }, 1000);
    });
}
