// Signup functionality
function continueWithPhone() {
    const phone = document.getElementById('phone').value;
    
    // Validate phone number
    if (!phone || phone.length !== 10) {
        alert('Please enter a valid 10-digit phone number');
        return;
    }

    // Store phone number in localStorage
    localStorage.setItem('userPhone', phone);
    
    // Redirect to OTP verification page
    window.location.href = 'otp.html';
}

// Social login handlers
function continueWithGoogle() {
    // Implement Google OAuth flow
    alert('Google signup coming soon!');
}

function continueWithFacebook() {
    // Implement Facebook OAuth flow
    alert('Facebook signup coming soon!');
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Add click handlers for social login buttons
    document.querySelector('.google-btn').addEventListener('click', continueWithGoogle);
    document.querySelector('.facebook-btn').addEventListener('click', continueWithFacebook);
});
