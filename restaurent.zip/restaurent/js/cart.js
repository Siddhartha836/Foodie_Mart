// Cart
// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    // Initialize cart
    initializeCart();
});

// Initialize cart
function initializeCart() {
    // Load cart items
    const cartItemsContainer = document.querySelector('.cart-items');
    const cartTotal = document.getElementById('cart-total');
    const cartSubtotal = document.getElementById('cart-subtotal');
    const cartItemCount = document.getElementById('cart-item-count');
    const checkoutBtn = document.getElementById('checkout-btn');
    const clearCartBtn = document.getElementById('clear-cart');

    // Get cart from localStorage
    let cart = JSON.parse(localStorage.getItem('cart')) || {};

    // Display cart items
    displayCartItems();

    // Update cart summary
    updateCartSummary();

    // Checkout button click handler
    checkoutBtn.addEventListener('click', () => {
        if (Object.keys(cart).length === 0) {
            alert('Your cart is empty!');
            return;
        }
        
        // Redirect to checkout
        window.location.href = 'checkout.html';
    });

    // Clear cart button click handler
    clearCartBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to clear your cart?')) {
            clearCart();
        }
    });
}

// Display cart items
function displayCartItems() {
    const cartItemsContainer = document.querySelector('.cart-items');
    cartItemsContainer.innerHTML = '';

    // Get cart from localStorage
    const cart = JSON.parse(localStorage.getItem('cart')) || {};

    Object.values(cart).forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-image">
                <img src="${item.image}" alt="${item.name}">
            </div>
            <div class="cart-item-info">
                <h3>${item.name}</h3>
                <p class="price">₹${item.price}</p>
                <p class="description">${item.description}</p>
                <div class="quantity-controls">
                    <button onclick="updateQuantity(${item.id}, -1)" class="quantity-btn">-</button>
                    <span class="quantity">${item.quantity}</span>
                    <button onclick="updateQuantity(${item.id}, 1)" class="quantity-btn">+</button>
                </div>
                <button onclick="removeFromCart(${item.id})" class="remove-btn">Remove</button>
            </div>
        `;
        cartItemsContainer.appendChild(cartItem);
    });
}

// Update cart summary
function updateCartSummary() {
    const cart = JSON.parse(localStorage.getItem('cart')) || {};
    
    // Calculate totals
    let itemCount = 0;
    let subtotal = 0;
    
    Object.values(cart).forEach(item => {
        itemCount += item.quantity;
        subtotal += item.price * item.quantity;
    });
    
    // Update UI
    document.getElementById('cart-item-count').textContent = itemCount;
    document.getElementById('cart-subtotal').textContent = `₹${subtotal}`;
    document.getElementById('cart-total').textContent = `₹${subtotal}`; // Delivery is free
}

// Update item quantity
function updateQuantity(itemId, change) {
    const cart = JSON.parse(localStorage.getItem('cart')) || {};
    if (cart[itemId]) {
        cart[itemId].quantity += change;
        
        if (cart[itemId].quantity <= 0) {
            delete cart[itemId];
        }
        
        localStorage.setItem('cart', JSON.stringify(cart));
        displayCartItems();
        updateCartSummary();
        
        // Show toast message
        showToast(change > 0 ? 'Quantity increased' : 'Quantity decreased');
    }
}

// Remove item from cart
function removeFromCart(itemId) {
    const cart = JSON.parse(localStorage.getItem('cart')) || {};
    if (cart[itemId]) {
        delete cart[itemId];
        localStorage.setItem('cart', JSON.stringify(cart));
        displayCartItems();
        updateCartSummary();
        showToast('Item removed from cart');
    }
}

// Clear cart
function clearCart() {
    localStorage.removeItem('cart');
    displayCartItems();
    updateCartSummary();
    showToast('Cart cleared');
}

// Toast message functionality
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Add animation
    toast.style.transform = 'translateY(0)';
    toast.style.opacity = '1';
    
    // Remove after 3 seconds
    setTimeout(() => {
        toast.style.transform = 'translateY(-100%)';
        toast.style.opacity = '0';
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}
